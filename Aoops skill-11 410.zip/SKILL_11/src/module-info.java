/**
 * 
 */
/**
 * 
 */
module SKILL11 {
	requires java.sql;
}