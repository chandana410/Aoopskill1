package music_streaming;

public class RadioPlayer {
    public void tune(String station) {
        System.out.println("Tuning into radio station: " + station);
    }
}
