package music_streaming;

public interface MusicPlayer {
    void play(String song);
}
