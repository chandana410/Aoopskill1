package music_streaming;

public class OnlineStreaming {
    public void stream(String song) {
        System.out.println("Streaming online: " + song);
    }
}
