package skill_9;

class UserThread extends Thread {
    private BankAccount account;
    private String userName;
    private int amount;

    public UserThread(BankAccount account, String userName, int amount) {
        this.account = account;
        this.userName = userName;
        this.amount = amount;
    }

    @Override
    public void run() {
        account.withdraw(userName, amount);
    }
}
