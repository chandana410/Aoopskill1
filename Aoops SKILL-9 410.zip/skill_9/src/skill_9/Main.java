package skill_9;

public class Main {
    public static void main(String[] args) {
        BankAccount account = new BankAccount();


        UserThread user1 = new UserThread(account, "Alice", 500);
        UserThread user2 = new UserThread(account, "Bob", 700);
        UserThread user3 = new UserThread(account, "Charlie", 300);


        user1.start();
        user2.start();
        user3.start();
    }
}

