package logging_system;

public enum LogLevel {
    INFO, DEBUG, ERROR
}
