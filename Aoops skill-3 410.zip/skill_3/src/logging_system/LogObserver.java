package logging_system;

public interface LogObserver {
    void update(String message);
}
