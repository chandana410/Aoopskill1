package test.sis.service;

public @interface Test {

}
