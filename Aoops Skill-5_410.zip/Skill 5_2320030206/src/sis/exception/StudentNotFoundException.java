package sis.exception;

// Custom Exception for Student Not Found
public class StudentNotFoundException extends RuntimeException {
    public StudentNotFoundException(String message) {
        super(message);
    }
}
